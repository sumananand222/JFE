package com.emart.pojo;

public class User {
	String uid;
	String fname;
	String lname;
	String uname;
	String password;
	String role;
	
	
	public User(String uid, String fname, String lname, String uname, String password, String role) {
		super();
		this.uid = uid;
		this.fname = fname;
		this.lname = lname;
		this.uname = uname;
		this.password = password;
		this.role = role;
	}


	@Override
	public String toString() {
		return "User [uid=" + uid + ", fname=" + fname + ", lname=" + lname + ", uname=" + uname + ", password="
				+ password + ", role=" + role + "]";
	}


	public String getUid() {
		return uid;
	}


	public void setUid(String uid) {
		this.uid = uid;
	}


	public String getFname() {
		return fname;
	}


	public void setFname(String fname) {
		this.fname = fname;
	}


	public String getLname() {
		return lname;
	}


	public void setLname(String lname) {
		this.lname = lname;
	}


	public String getUname() {
		return uname;
	}


	public void setUname(String uname) {
		this.uname = uname;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
