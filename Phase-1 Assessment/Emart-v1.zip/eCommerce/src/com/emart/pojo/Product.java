package com.emart.pojo;

public class Product {
	String pid;
	String pname;
	String pmake;
	String pmodel;
	String price;
	String qty;
	String sellerId;
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPmake() {
		return pmake;
	}
	public void setPmake(String pmake) {
		this.pmake = pmake;
	}
	public String getPmodel() {
		return pmodel;
	}
	public void setPmodel(String pmodel) {
		this.pmodel = pmodel;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getQty() {
		return qty;
	}
	public void setQty(String qty) {
		this.qty = qty;
	}
	public String getSellerId() {
		return sellerId;
	}
	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}
	public Product(String pid, String pname, String pmake, String pmodel, String price, String qty, String sellerId) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.pmake = pmake;
		this.pmodel = pmodel;
		this.price = price;
		this.qty = qty;
		this.sellerId = sellerId;
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Product [pid=" + pid + ", pname=" + pname + ", pmake=" + pmake + ", pmodel=" + pmodel + ", price="
				+ price + ", qty=" + qty + ", sellerId=" + sellerId + "]";
	}
	
	
}
