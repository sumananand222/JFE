package com.emart.controller;

import java.util.Scanner;

import com.emart.pojo.Product;
import com.emart.service.*;

public class Controller {
	static productServ productserv=new productServImpl();
	Product prod=new Product();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ValidateUser vu=new ValidateUserImpl();
		System.out.println("=========Welcome to Emart=========");
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter:\n1 for Seller\n2 for Buyer:");
		int role= sc.nextInt();
		System.out.println("To login, enter 1\nTo create a new account, enter 2");
		int option= sc.nextInt();
		if (vu.ValidateUserServ(role,option)==1) {
			System.out.println("Logged in Successfully!");
			System.out.println("Select option to perform:\n1 for search\n2 for add\n3 for update");
			int action=sc.nextInt();
			if(action==1) {
				productserv.searchProduct(sc.next());
				System.out.println();
			}
			else if(action==2) {
				productserv.addProduct();
			}
			else if(action==3) {
				productserv.updateProduct();
			}
			else {
				System.out.println("Invalid Input");
			}
			
		}
		else if (vu.ValidateUserServ(role,option)==2) {
			System.out.println("Account created Successfully!");
		}
		else {
			System.out.println("Invalid User Values!");
		}
	}

}
