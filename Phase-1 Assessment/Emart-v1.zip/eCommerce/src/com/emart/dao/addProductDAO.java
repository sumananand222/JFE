package com.emart.dao;

import com.emart.pojo.*;

public interface addProductDAO {
	int addProduct(Product details);
}
