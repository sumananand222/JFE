package com.emart.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.emart.pojo.*;

public class updateProductDAOImpl implements updateProductDAO{
	Product details = new Product();
	addProductDAO adddao = new addProductDAOImpl();
	public Product updateProduct(Product prod) {
		Connection conn = null;
		   PreparedStatement pstmt2 = null;
		   
		   try {
		      conn = DBUtil.dbConnection();
		      
		      String sql = "SELECT * FROM product WHERE pname=? OR pmake=? OR pmodel=? or price=?";
		      pstmt2 = conn.prepareStatement(sql);
		      pstmt2.setString(1, details.getPname());
		      pstmt2.setString(2, details.getPmake());
		      pstmt2.setString(3, details.getPmodel());
		      pstmt2.setString(4, details.getPrice());
		      ResultSet rs = pstmt2.executeQuery();
			         System.out.println("traversed product if");
			      details.setPid(rs.getString("productid"));
			         details.setPname(rs.getString("pname"));
			         details.setPmake(rs.getString("pmake"));
			         details.setPmodel(rs.getString("pmodel"));
			         details.setPrice(rs.getString("price"));
			         details.setQty(rs.getString("qty"));
			         details.setSellerId(rs.getString("sellerid"));
			         System.out.println("got product db values");
			      System.out.println(details);			      
			      adddao.addProduct(details);
			      
		      return details;
	   } catch (Exception e) {
		      System.out.println("Exception :"+ e.getMessage());
		      return details;
		   } finally {
		      try {
		         pstmt2.close();
		         conn.close();
		      } catch (SQLException e) {
		         System.out.println("SQLException :"+ e.getMessage());
		      return details;
		      } 
		      
		   }
	}

}