package com.emart.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.emart.pojo.*;

public class searchProductDAOImpl implements searchProductDAO{
	Product details = new Product();
	public Product searchProduct(String value) {
			Connection conn = null;
			   PreparedStatement pstmt = null;
			   
			   try {
			      conn = DBUtil.dbConnection();
			      
			      String sql = "SELECT * FROM product WHERE pname=? OR pmake=? OR pmodel=? or price=?";
			      pstmt = conn.prepareStatement(sql);
			      pstmt.setString(1, value);
			      pstmt.setString(2, value);
			      pstmt.setString(3, value);
			      pstmt.setString(4, value);
			      ResultSet rs = pstmt.executeQuery();
			      while(rs.next()) {
			         if(!rs.getString("pname").equals("") && !rs.getString("pmake").equals("") && !rs.getString("pmodel").equals("") && !rs.getString("price").equals("")) {
			            if (!rs.getString("pname").equals(value) && !rs.getString("pmake").equals(value) && !rs.getString("pmodel").equals(value) && !rs.getString("price").equals(value))
			               System.out.println("Invalid Inputs");
			         }
			         System.out.println("traversed product if");
			         details.setPname(rs.getString("pname"));
			         details.setPmake(rs.getString("pmake"));
			         details.setPmodel(rs.getString("pmodel"));
			         details.setPrice(rs.getString("price"));
			         System.out.println("got product db values");
			      }
			      return details;
			   } catch (Exception e) {
			      System.out.println("Exception :"+ e.getMessage());
			      return details;
			   } finally {
			      try {
			         pstmt.close();
			         conn.close();
			      } catch (SQLException e) {
			         System.out.println("SQLException :"+ e.getMessage());
			      return details;
			      } 
			      
			   }
		}

	}

