package com.emart.dao;

import java.util.Scanner;

import com.emart.pojo.Product;

public class fillValues {
    public Product fillValues() {
    	Scanner sc = new Scanner(System.in);
    	Product p1=new Product();
    	System.out.println("Enter Product Name:");
    	String pname=sc.next();
    	System.out.println("Enter Product Make:");
    	String pmake=sc.next();
    	System.out.println("Enter Product Model:");
    	String pmodel=sc.next();
    	System.out.println("Enter Product Price:");
    	String price=sc.next();
    	System.out.println("Enter Product Quantity:");
    	String qty=sc.next();
    	System.out.println("Enter Product SellerId:");
    	String sellerid=sc.next();
    	p1.setPname(pname);
    	return p1;
    }
    public Product fillValues(Product prod) {
    	Scanner sc = new Scanner(System.in);
    	Product p1=new Product();
    	System.out.println("Enter Product Name:");
    	String pname=sc.next();
    	System.out.println("Enter Product Make:");
    	String pmake=sc.next();
    	System.out.println("Enter Product Model:");
    	String pmodel=sc.next();
    	System.out.println("Enter Product Price:");
    	String price=sc.next();
    	System.out.println("Enter Product Quantity:");
    	String qty=sc.next();
    	System.out.println("Enter Product SellerId:");
    	String sellerid=sc.next();
    	p1.setPname(pname);
    	return p1;
    }
}
