package com.emart.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.emart.pojo.User;

public class SignUpDAOImpl implements SignUpDAO{
	public int SignUpUser(User details) {	
	Connection conn = null;
	   PreparedStatement pstmt = null;
	   try {
	      conn = DBUtil.dbConnection();
	      
	      String sql1 = "INSERT INTO user (fname, lname, username,password,role)" +
	              "VALUES (?, ?, ?, ?, ?)";
	      pstmt = conn.prepareStatement(sql1);
	      pstmt.setString(1, details.getFname());
	      pstmt.setString(2, details.getLname());
	      pstmt.setString(3, details.getUname());
	      pstmt.setString(4, details.getPassword());
	      pstmt.setString(5, details.getRole());
	      pstmt.executeUpdate();
	      
	   } catch (Exception e) {
		   System.out.println("Exception :"+ e.getMessage());
	   } finally {
	      try {
	         pstmt.close();
	         conn.close();
	      } catch (SQLException e) {
	         System.out.println("SQLException :"+ e.getMessage());
	      }  
	   
	   }
	   return 1;
	}
	
}
