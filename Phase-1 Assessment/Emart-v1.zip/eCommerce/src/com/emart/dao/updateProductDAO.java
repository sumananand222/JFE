package com.emart.dao;

import com.emart.pojo.Product;

public interface updateProductDAO {
	Product updateProduct(Product prod);
}
