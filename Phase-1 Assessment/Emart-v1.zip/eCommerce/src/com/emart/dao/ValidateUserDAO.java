package com.emart.dao;
import java.util.*;

public interface ValidateUserDAO {
	int ValidateUser(String username,String password);
}
