package com.emart.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.emart.pojo.*;

public class ValidateUserDAOImpl implements ValidateUserDAO{
	User details =new User();
	public int ValidateUser(String username, String password) {
		Connection conn = null;
		   PreparedStatement pstmt = null;
		   
		   try {
		      conn = DBUtil.dbConnection();
		      
		      String sql = "SELECT * FROM User WHERE username=? AND password=?";
		      pstmt = conn.prepareStatement(sql);
		      pstmt.setString(1, username);
		      System.out.println(username);
		      pstmt.setString(2, password);
		      System.out.println(password);
		      ResultSet rs = pstmt.executeQuery();
		      while(rs.next()) {
		         if(!rs.getString("username").equals("") && !rs.getString("password").equals("")) {
		            if (!rs.getString("username").equals(username) && !rs.getString("password").equals(password))
		               System.out.println("Invalid Inputs");
		         }
		         System.out.println("traversed if");
		         
		         details.setFname(rs.getString("fname"));
		         details.setLname(rs.getString("lname"));
		         details.setUname(rs.getString("username"));
		         details.setPassword(rs.getString("password"));
		         details.setRole(rs.getString("role"));
		         System.out.println("got db values");
		      }
		      return 1;
		   } catch (Exception e) {
		      System.out.println("Exception :"+ e.getMessage());
		      return -1;
		   } finally {
		      try {
		         pstmt.close();
		         conn.close();
		      } catch (SQLException e) {
		         System.out.println("SQLException :"+ e.getMessage());
		      return -1;
		      } 
		      
		   }
	}
	
}
