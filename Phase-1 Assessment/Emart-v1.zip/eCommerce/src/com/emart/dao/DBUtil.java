package com.emart.dao;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {

	   public static Connection dbConnection() throws IOException, Exception {
	      
//	      Properties p=new Properties();         
//	       InputStream inputStream = ClassLoader.getSystemClassLoader().getResourceAsStream("dbcred.properties");
//	       p.load(inputStream);
		   String url= "jdbc:mysql://localhost:3306/emart?"+"autoReconnect=true&useSSL=false";
	      Connection conn = null;
	      try {
	         Class.forName("com.mysql.jdbc.Driver");
	      } catch (ClassNotFoundException e) {
	         System.out.println(""+ e.getMessage());
	      }
	      try {
	    	  conn = DriverManager.getConnection(url,
	                  "root", "anik");
	   
	         //conn = (Connection) DriverManager.getConnection(p.getProperty("url"), p.getProperty("emart"), p.getProperty("anik"));
	      } catch (SQLException e) {
	    	  System.out.println(""+ e.getMessage());
	      }
	      return conn;
	         
	   }
}