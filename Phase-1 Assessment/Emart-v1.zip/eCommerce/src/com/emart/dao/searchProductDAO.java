package com.emart.dao;

import com.emart.pojo.Product;

public interface searchProductDAO {
	Product searchProduct(String value);
}
