package com.emart.dao;

import com.emart.pojo.*;

public interface fillValuesDAO {
	Product fillValues();
	Product fillValues(Product prod);
}
