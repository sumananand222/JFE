package com.emart.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.emart.pojo.*;

public class addProductDAOImpl implements addProductDAO {
	Product details = new Product();
	public int addProduct(Product prod) {
		fillValuesDAO fvdao = (fillValuesDAO) (prod);
		
				Connection conn = null;
				   PreparedStatement pstmt = null;
				   try {
				      conn = DBUtil.dbConnection();

				      String sql1 = "INSERT INTO product (pname, pmake, pmodel,price,qty,sellerid)" +
				              "VALUES (?, ?, ?, ?, ?)";
				      pstmt = conn.prepareStatement(sql1);
				      pstmt.setString(1, details.getPname());
				      pstmt.setString(2, details.getPmake());
				      pstmt.setString(3, details.getPmodel());
				      pstmt.setString(4, details.getPrice());
				      pstmt.setString(5, details.getQty());
				      pstmt.setString(6, details.getSellerId());
				      ResultSet rs = pstmt.executeQuery();
				      
				   } catch (Exception e) {
					   System.out.println("Exception :"+ e.getMessage());
				   } finally {
				      try {
				         pstmt.close();
				         conn.close();
				      } catch (SQLException e) {
				         System.out.println("SQLException :"+ e.getMessage());
				      }  
				   
				   }
				   return 1;
				}
}
