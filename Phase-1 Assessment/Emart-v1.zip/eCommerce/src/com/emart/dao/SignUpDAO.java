package com.emart.dao;

import com.emart.pojo.*;

public interface SignUpDAO {
	int SignUpUser(User details);
}
