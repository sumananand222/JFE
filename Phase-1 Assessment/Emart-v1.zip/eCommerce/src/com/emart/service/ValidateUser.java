package com.emart.service;

public interface ValidateUser {
	int ValidateUserServ(int role,int option);
}
