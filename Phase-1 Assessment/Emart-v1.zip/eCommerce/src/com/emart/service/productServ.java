package com.emart.service;

import com.emart.pojo.*;

public interface productServ {
	void searchProduct(String value);
	int addProduct();
	Product updateProduct();
	
}
