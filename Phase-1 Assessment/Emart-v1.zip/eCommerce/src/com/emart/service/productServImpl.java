package com.emart.service;

import com.emart.pojo.*;
import com.emart.dao.*;

public class productServImpl implements productServ{
	addProductDAO adddao = new addProductDAOImpl();
	searchProductDAO searchdao = new searchProductDAOImpl();
	updateProductDAO updatedao = new updateProductDAOImpl();
	fillValuesDAO fvdao=(fillValuesDAO) new fillValues() ;//= new fillValues();
	Product prod=new Product();
	public void searchProduct(String value) {
		 prod = searchdao.searchProduct(value);
		System.out.println(prod);
//		return 
	}
	public int addProduct() {
	//	fvdao = adddao.addProduct(prod);
		return 1;
	}
	public Product updateProduct() {
		return updatedao.updateProduct(prod);
	}
}
