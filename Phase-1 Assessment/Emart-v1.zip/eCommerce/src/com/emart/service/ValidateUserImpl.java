package com.emart.service;

import java.util.Scanner;
import com.emart.dao.*;
import com.emart.pojo.*;

public class ValidateUserImpl implements ValidateUser{
	ValidateUserDAO dao = new ValidateUserDAOImpl();
	SignUpDAO daos = new SignUpDAOImpl();
	User details;
	public int ValidateUserServ(int role,int option) {
		
		if((role==1 || role==2 )&& option==1) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter username:");
			String username=sc.next();
			System.out.println("Enter password:");
			String password=sc.next();
			
			return dao.ValidateUser(username,password);
		}
		else {	
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter firstname:");
			String fname=sc.next();
			System.out.println("Enter lastname:");
			String lname=sc.next();
			System.out.println("Enter username:");
			String uname=sc.next();
			System.out.println("Enter password:");
			String pwd=sc.next();
			String role1= Integer.toString(role);
			details.setFname(fname);
			details.setLname(lname);
			details.setUname(uname);
			details.setPassword(pwd);
			details.setRole(role1);
			return daos.SignUpUser(details);
		}
	}
}
