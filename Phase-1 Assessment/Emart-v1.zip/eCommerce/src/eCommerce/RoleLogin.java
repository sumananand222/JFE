//package eCommerce;
//
//import java.util.Scanner;
//
//class login extends Application{
//
//	
//	int role;
//	int through;
//	Scanner input = new Scanner(System.in);
//
//	
//	
//	public void SelectingRole() {
//		
//		role = input.nextInt();
//		if(role == 1) {
//			seller();
//		} 
//		else if(role == 2){
//			buyer();
//		}
//	}
//
//	void seller() {
//			System.out.println("Welcome to Seller Portal");
//			System.out.println("Type '1' if you want to Login");
//			System.out.println("Type '2' if you want to Signup");
//			through = input.nextInt();
//			if(through == 1) {
//				login();
//			} else {
//				signup();
//			}
//			
//	}
//	void buyer() {
//			System.out.println("Welcome to Buyer Portal");
//			System.out.println("Type '1' if you want to Login");
//			System.out.println("Type '2' if you want to Signup");
//			through = input.nextInt();
//			if(through == 1) {
//				login();
//			} else {
//				signup();
//			}
//	}
//	
//	void login() {
//		System.out.println("Enter ID : ");
//		String ID = input.next();
//		System.out.print("Enter password : ");
//		String Password = input.next();
//		String IDtrial = "asdf";                                         //table for seller and buyer different for login.
//		String Passwordtrial = "asdf1234";
//		if(ID.equals(IDtrial) && Password.equals(Passwordtrial)) {
//			System.out.println("Successfully logged In");
//			if(role == 1) {
//				SellerOperation();
//			} else {
//				BuyerOperation();
//			}
//		} else {
//			System.out.println("Does not exist/match");
//		}
//		
//	}
//	
//	void signup() {
//		System.out.print("Create ID : ");
//		String ID = input.next();
//		System.out.print("Create password : ");
//		String Password = input.next();
//		System.out.println("Signed up");                      //signedup will insert value to resp table for seller and buyer.
//	}
//	
//	
//	void SellerOperation() {
//		
//	}
//	
//	
//	void BuyerOperation() {
//		
//	}
//	
//}
//
//public class RoleLogin {
//
//	public static void main(String[] args) {
//
//		
//		System.out.println("Welcome to eCommerce Application");
//		System.out.println("Select a role for you :");
//		System.out.println("1. Seller");
//		System.out.println("2. Buyer");
//		
//		employee emp = new employee();
//		emp.SelectingRole();
//		
//	}
//}
