package eCommerce;

public class Application {
	


	public static void main(String[] args) {
		
		Application app = new Application();

	}

}
